import * as React from 'react';
import { Fragment } from 'react';
import { ContactForm } from '../components/contact/ContactForm';

export const Contact = () => {
  return (
    <Fragment>
      <ContactForm />
    </Fragment>
  );
};
